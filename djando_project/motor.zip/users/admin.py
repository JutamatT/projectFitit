from django.contrib import admin
from .models import Profile,Review,UserP

admin.site.register(Profile)
admin.site.register(UserP)

